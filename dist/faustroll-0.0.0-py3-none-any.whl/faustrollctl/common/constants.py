import os

RC_OK = 0
RC_BAD = 1

PANMUPHLECTL_PATH = os.path.expanduser("~/.local/bin/panmuphlectl")
