

def cite_from_chromium():
    pass