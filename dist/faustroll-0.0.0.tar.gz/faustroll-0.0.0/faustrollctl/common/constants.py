import os

RC_OK = 0
RC_BAD = 1

STATE_DIR = os.path.expanduser("~/.local/state/faustroll")

PANMUPHLECTL_PATH = os.path.expanduser("~/.local/bin/panmuphlectl")
